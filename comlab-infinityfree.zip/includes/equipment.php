<?php

class Equipment
{
private $conn;

public function __construct($db)
{
$this->conn = $db;
}

// ADD EQUIPMENT
public function addEquipment($name, $status, $purchaseDate)
{
try {
$sql = "INSERT INTO equipment
(Equipment_Name, Status, Purchase_Date)
VALUES (:name, :status, :purchaseDate)";

$stmt = $this->conn->prepare($sql);

$stmt->bindParam(":name", $name);
$stmt->bindParam(":status", $status);
$stmt->bindParam(":purchaseDate", $purchaseDate);

return $stmt->execute();

} catch (PDOException $e) {
echo "Error adding equipment: " . $e->getMessage();
return false;
}
}

// GET ALL EQUIPMENT
public function getEquipments()
{
try {
$sql = "SELECT * FROM equipment
ORDER BY Equipment_ID DESC";

$stmt = $this->conn->prepare($sql);
$stmt->execute();

return $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
echo "Error fetching equipment: " . $e->getMessage();
return [];
}
}

// UPDATE EQUIPMENT
public function updateEquipment($id, $name, $status, $purchaseDate)
{
try {
$sql = "UPDATE equipment
SET Equipment_Name = :name,
Status = :status,
Purchase_Date = :purchaseDate
WHERE Equipment_ID = :id";

$stmt = $this->conn->prepare($sql);

$stmt->bindParam(":id", $id);
$stmt->bindParam(":name", $name);
$stmt->bindParam(":status", $status);
$stmt->bindParam(":purchaseDate", $purchaseDate);

return $stmt->execute();

} catch (PDOException $e) {
echo "Error updating equipment: " . $e->getMessage();
return false;
}
}

// DELETE EQUIPMENT
public function deleteEquipment($id)
{
try {
$sql = "DELETE FROM equipment
WHERE Equipment_ID = :id";

$stmt = $this->conn->prepare($sql);

$stmt->bindParam(":id", $id);

return $stmt->execute();

} catch (PDOException $e) {
echo "Error deleting equipment: " . $e->getMessage();
return false;
}
}

// SEARCH EQUIPMENT
public function searchEquipments($keyword)
{
try {
$sql = "SELECT * FROM equipment
WHERE Equipment_ID LIKE :keyword
OR Equipment_Name LIKE :keyword
OR Status LIKE :keyword
OR Purchase_Date LIKE :keyword
ORDER BY Equipment_ID DESC";

$stmt = $this->conn->prepare($sql);

$search = "%" . $keyword . "%";

$stmt->bindParam(":keyword", $search);

$stmt->execute();

return $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
echo "Error searching equipment: " . $e->getMessage();
return [];
}
}
}
?>